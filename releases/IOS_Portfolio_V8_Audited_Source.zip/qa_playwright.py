"""Offline, deterministic UI regression checks; assets intentionally unavailable over network."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json,time
root=Path(__file__).resolve().parent
html=(root/'dist/preview.html').read_text()
html=re.sub(r'<link[^>]*>', '', html)
routes=['/','/about','/portfolio','/contact','/portfolio/travel-easy','/portfolio/gamma','/portfolio/stream-ai','/portfolio/foome','/portfolio/edbost','/route-not-found']
widths=[320,375,390,768,1024,1640,1920]
results=[];errors=[];screens=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1640,'height':785},device_scale_factor=1)
 page.on('pageerror',lambda e:errors.append({'message':str(e),'stack':e.stack}))
 page.route('**/*',lambda route:route.abort())
 page.set_content(html,wait_until='domcontentloaded',timeout=18000)
 for width in widths:
  page.set_viewport_size({'width':width,'height':850 if width<700 else 900})
  for path in routes:
   page.evaluate('(path)=>{window.__previewPath=path;render()}',path)
   m=page.locator('#main')
   assert m.count()==1, ('main missing',path,width)
   assert m.locator('h1').count()>0, ('heading missing',path,width)
   actual=page.evaluate('({w:document.documentElement.scrollWidth,b:document.body.scrollWidth,c:document.querySelector(".content-wrap").getBoundingClientRect().width})')
   assert actual['w']<=width+1 and actual['b']<=width+1,(path,width,actual)
   missing_href=page.locator('a:not([href])').count()
   assert missing_href==0,(path,width,missing_href)
   if path=='/contact': assert page.locator('#contact-form').count()==1
   if path.startswith('/portfolio/') and path!='/portfolio/':assert page.locator('.case-heading h1').count()==1
   results.append({'path':path,'width':width,'result':'pass'})
  if width in (390,1640):
   page.evaluate("window.__previewPath='/';render()")
   page.wait_for_timeout(150)
   name=f'V8_home_{width}px.png'
   page.screenshot(path=str(root/name),animations='disabled',timeout=12000)
   screens.append(name)
 # Buttons/links and form validation
 page.set_viewport_size({'width':1440,'height':900})
 page.evaluate("window.__previewPath='/';render()")
 assert page.locator('.bento-card').count()==6
 page.locator('a[href="/about"]').first.click()
 assert page.locator('.about-intro').count()==1
 page.locator('a[href="/"][data-link]').first.click()
 assert page.locator('.bento-card').count()==6
 page.locator('a[href="/portfolio"]').first.click()
 assert page.locator('.portfolio-grid .project-tile').count()==5
 page.locator('a[href="/portfolio/gamma"]').first.click()
 assert page.locator('.case-heading h1').inner_text().strip()=='Gamma'
 page.locator('a[href="/portfolio/stream-ai"]').first.click()
 assert 'Stream AI' in page.locator('.case-heading h1').inner_text()
 page.evaluate("window.__previewPath='/contact';render()")
 page.locator('button[type="submit"]').click()
 assert 'highlighted' in page.locator('#form-status').inner_text()
 page.locator('input[name="name"]').fill('Test User')
 page.locator('input[name="email"]').fill('test@example.com')
 page.locator('input[name="projectType"]').first.check()
 page.locator('input[name="budget"]').first.check()
 page.locator('button[type="submit"]').click()
 assert 'Preview only' in page.locator('#form-status').inner_text()
 assert 'no message was sent' in page.locator('#form-status').inner_text()
 assert page.locator('a[href="https://x.com/"]').count()==0
 assert page.locator('a[href="https://www.instagram.com/"]').count()==0
 assert page.locator('a[href="https://www.linkedin.com/"]').count()==0
 theme=page.locator('button.theme-toggle')
 theme.click()
 assert page.evaluate("document.documentElement.dataset.theme")=='light'
 theme.click()
 assert page.evaluate("document.documentElement.dataset.theme")=='dark'
 page.evaluate('window.scrollTo({top:800,left:0,behavior:"instant"})')
 page.locator('a[data-scroll-top]').click()
 page.wait_for_timeout(1500)
 assert page.evaluate('window.scrollY')<100, page.evaluate('window.scrollY')
 page.evaluate("window.__previewPath='/about';render()")
 assert page.locator('[data-quote]').count()==2
 assert page.locator('[data-quote="prev"]').is_disabled()
 page.locator('[data-quote="next"]').click()
 page.wait_for_timeout(450)
 assert not page.locator('[data-quote="prev"]').is_disabled()
 # 404 fallback and metadata
 page.evaluate("window.__previewPath='/not-found';render()")
 assert page.locator('.not-found').count()==1
 assert 'Page not found' not in page.title() or 'Soren' in page.title()
 print("BROWSER ERRORS",errors)
 assert not errors, errors
 b.close()
print(json.dumps({'checks':len(results),'widths':widths,'routes':len(routes),'errors':errors,'screenshots':screens,'functional_assertions':'passed'},indent=2))
(root/'QA_PLAYWRIGHT_RESULTS.json').write_text(json.dumps({'checks':len(results),'widths':widths,'routes':len(routes),'errors':errors,'screenshots':screens,'functional_assertions':'passed'},indent=2))
