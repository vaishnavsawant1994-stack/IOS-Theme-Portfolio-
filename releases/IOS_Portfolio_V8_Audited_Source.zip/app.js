/* VEXOO-INSPIRED RECREATION — editable, dependency-free. Original template: TE Studio / Framer. */
const IMG = 'https://framerusercontent.com/images/';
// Editable values live in site-config.js. The public preview intentionally uses demo data.
const siteConfig = window.IOS_PORTFOLIO_CONFIG || {};
const isDemo = siteConfig.mode !== 'production';
const pageDescriptions = {
 '/': 'A considered portfolio of digital design, visual craft and creative projects.',
 '/about': 'Learn about the approach, experience and creative practice behind the portfolio.',
 '/portfolio': 'Selected digital products, visual design, websites and case studies.',
 '/contact': 'Get in touch about product design, visual identity and website projects.'
};

const ABOUT_IMAGE = '7esgEDTfqoCmh2yHxI65XfkMOCI.jpg';
const profile = {
  name: siteConfig.name || 'Soren Weil', role: siteConfig.role || 'AI Design Engineer', email: siteConfig.email || 'hello@soren.com', phone: siteConfig.phone || '(+20) 115 123-4567',
  resume: siteConfig.resume || 'https://drive.google.com/file/d/167um-hT0g-Xc2ClPDNb0z40feV9LT7e2/view?usp=drive_link',
  social: [
    ['X (Twitter)', siteConfig.socialHandles?.x || '@soren.weil', siteConfig.socialProfiles?.x || ''],
    ['Instagram', siteConfig.socialHandles?.instagram || '@its-soren', siteConfig.socialProfiles?.instagram || ''],
    ['LinkedIn', siteConfig.socialHandles?.linkedin || '@weil.soren', siteConfig.socialProfiles?.linkedin || '']
  ]
};
const tools = [
 ['Claude','TYnAWe40HMxz4pwJRcf5ydnQEdc.webp'],
 ['Framer','0j5gYeoRsZG8PJ9hniVzHMcaYo.webp'],
 ['Figma','YSG9Il0233T2Woq4Fpetvt6FxGA.webp'],
 ['Lovable','xWqhGd7U96VfwGOWXINLwTZ7NE.webp'],
 ['Notion','nPHFl0RBkV6slUv4Uoim7EwewOw.webp'],
 ['Arc','zGAt4WY8OJbwRWMnilWeItDaR84.webp'],
 ['Linear','vbYkTRxoFHB1KElmmjmXx9TSsU.webp'],
 ['Screen Studio','NM6rQRZGZg9gw7HcNBtder6J2M.webp']
];
const projects = [
 { slug:'travel-easy',title:'Travel Easy',category:'App Design',client:'Wardou',role:'Product Designer',year:'2021',
   description:'A story-driven travel experience spotlighting local traditions, lesser-known destinations, and diverse cultural voices beyond traditional sightseeing guides.',
   challenge:'Conventional travel guides often focused on famous landmarks, leaving curious travelers without the voices and experiences that make each destination special.',
   objective:'Create a more personal platform for discovering places, combining curated storytelling, contributions from locals, and useful trip-planning experiences.',
   results:'The idea grew into a destination for culturally curious travelers, with an expanded collection of experiences and collaborations with independent creators.',
   images:['JAuzg1K8J6MK83hAIIrvRYRaf8.webp','xGRYycdwlW5h939lgDKhSUWvQ.webp','kjvpqYpzKvdJSXtFreVieyc1I.webp','OiycQfUThB8UTI5Bef2fzpB4.webp','S1qtYIs0dQ6Khor8ygFagQ7nQ.webp','2fVg7UegdrwQrbFJWOgW8o3Flk.webp','L0xOTBZtwmOQzTW3sRX9u5MxQio.webp'] },
 { slug:'gamma',title:'Gamma',category:'UX/UI Design',client:'David B.',role:'UX Designer',year:'2022',
   description:'Gamma is an AI presentation, document, and website creation platform. This website design work focused on usability, clear value communication, and conversions.',
   challenge:'The experience needed sharper explanations and easier paths into the product, particularly for newcomers evaluating whether it met their creative needs.',
   objective:'Redesign the communication and interface patterns to clarify the value proposition, highlight useful features, and support confident exploration.',
   results:'A clearer creative direction, more direct calls to action, and stronger visual storytelling helped give the product an accessible first impression.',
   images:['93E7FcdSSqHVNH5lLB9gLOZd20.webp','vgSaCQh5i7EIFr9BVRj7b0kg8sE.webp','mGMSmPqJpTuar8BTXn82QMMUw.webp','og2Bzo2xKUwTONLdhlBTPTAE.webp','K7TOK58lFcmt2ledRk8p19BHzfw.webp','5LN2CWGN6A2IPBSwvfzQIohR8c.webp','2hnYIN8k3MxIgmayYcdBjCPmneU.webp'] },
 { slug:'stream-ai',title:'Stream AI',category:'Product Design',client:'Robert L.',role:'UI Designer',year:'2023',
   description:'A collaborative production experience created to connect editors, directors, and clients through clear feedback, review, and approvals.',
   challenge:'Production feedback was scattered among emails and file versions, resulting in repeated reviews and uncertainty about the latest decisions.',
   objective:'Bring directors, editors, and stakeholders into a shared interface where creative work can be reviewed and annotated without friction.',
   results:'A unified workflow concept that simplifies communication, strengthens creative alignment, and makes remote reviews more transparent.',
   images:['eO0GqBm897hz4DedM2o4BNk0Og.webp','Te79dkTp7HS0DCLKtZZdepOmvM.webp','XP7iyAUM2vqIcPQgfEVeNeuNw.webp','ixjAuPBAjfElxZd8FzDcvSK5MO8.webp','yZS6ReNgqnNH5l36cD8mt2oEeY.webp','gp3EWvQV9htZLs9WqlUe3VsTKlQ.webp','QDKhGivuHXLTwJ5gTfoU3lhJaA.webp'] },
 { slug:'foome',title:'Foome',category:'Web Design',client:'Carles P.',role:'Product Designer',year:'2024',
   description:'An interactive, step-by-step cooking experience with clear guidance, adjustable portions, and intuitive assistance for home cooks.',
   challenge:'Recipe platforms demanded too much scrolling, switching tabs, and keeping track of instructions while working hands-on in the kitchen.',
   objective:'Design a calmer cooking companion with sequential steps, flexible portions, timers, and accessible prompts for home cooks.',
   results:'The resulting interface concept celebrates food imagery while making recipes easier to discover, plan, follow, and return to.',
   images:['suNAtAxC3jc1slGxH2TAGQ4rtp0.webp','P1sQTtvTLxL0DzyVFNgK5MNTIvg.webp','5dyvJtvS8xzvryK7VT2ZAHHq6Y.webp','lRnkfOVczkAMOiaAs6VyYzA2xbQ.webp','R8n5nYWo6EsXMhDfdmiVFPZ9Rc.webp','qjLV5NRoQUJhXuXvAI5PAMWJ0.webp','EtqudsophlBRIABEi4CxMsa4.webp'] },
 { slug:'edbost',title:'Edbost',category:'Visual Design',client:'Alex T.',role:'UX Designer',year:'2025',
   description:'An accessible, cloud-based creative toolkit for independent video makers, helping artists explore advanced visual effects and AI editing.',
   challenge:'Sophisticated editing and effects tools were often expensive or difficult to navigate, particularly for small teams and solo artists.',
   objective:'Make advanced creative workflows feel approachable through a cloud-based interface and a clear suite of intelligent tools.',
   results:'A versatile visual system that connects experimentation, practical editing tools, and community-focused storytelling into a coherent experience.',
   images:['WWkZxpeT2EaVFcbABkjOiVgjd9U.webp','XlUcranWAKacMI37gtUV2YQNQ.webp','bJ5YWD45IIgDmwA6qioKsFI36Y.webp','IqAh9MqffVn0kQaEPuaNUlbihvw.webp','jdrPw7GoxXN8o9QCUhoNLV7jo.webp','HFVbeUSPceWVJlqRulppu1gung.webp','crPRqo2r4AvfXfdM7VKcrHk.webp'] }
];
const testimonials = [
 ['Marcus Holm','Fenwick Studio','Soren balances a strong creative vision with an unusually close eye for detail. Every project feels carefully considered, yet the process remains natural and collaborative.'],
 ['Layla Thornton','Dayloom','He has a gift for asking questions that uncover the real challenge beneath a brief. His clarity and sensitivity helped us make decisions with greater confidence.'],
 ['Jin Park','Haulk','A generous, thoughtful creative partner with distinctive taste and the patience to improve every detail. The entire team came away with stronger ideas and a better result.'],
 ['Nadia Osei','Morsel','It is rare to find a designer who combines such a precise point of view with genuine curiosity about others. The collaboration felt ambitious without ever feeling rigid.'],
 ['Reem Saleh','Vaulted','He listens first and designs with calm conviction. What begins as a complicated set of possibilities becomes an idea that seems obvious only after he has made it clear.']
];
const experiences = [
 ['2026 – Present','Design Director','Incase','Led visual direction across product, digital, and physical experiences. Guided a multidisciplinary team, shaped new product launches and coordinated campaigns with a focus on customer engagement and coherent storytelling.'],
 ['2023 – 2025','Design Lead','Grey','Directed the digital execution of brand and product campaigns with distributed creative teams. Established clearer systems for collaborative reviews while protecting detail, usability, and the quality of each final delivery.'],
 ['2020 – 2022','Senior Designer','Shopify','Partnered with researchers, product managers, and engineers to make complex merchant workflows easier to understand. Built components, tested onboarding concepts, and helped raise accessibility and consistency standards.'],
 ['2018 – 2020','UX/UI Designer','Shrink','Worked with founders to understand early customer needs and turn research into practical product decisions. Shaped interface patterns, onboarding flows, and a recognizable visual language for a growing service.']
];
const iconArrow = '<svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 19 19 5M8 5h11v11"/></svg>';
const iconBack = '<svg class="back-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5m7-7-7 7 7 7"/></svg>';
const iconFiles = {'TYnAWe40HMxz4pwJRcf5ydnQEdc.webp':'/assets/logos/claude.svg','0j5gYeoRsZG8PJ9hniVzHMcaYo.webp':'/assets/logos/framer.svg','YSG9Il0233T2Woq4Fpetvt6FxGA.webp':'/assets/logos/figma.svg','xWqhGd7U96VfwGOWXINLwTZ7NE.webp':'/assets/logos/lovable.svg','nPHFl0RBkV6slUv4Uoim7EwewOw.webp':'/assets/logos/notion.svg','zGAt4WY8OJbwRWMnilWeItDaR84.webp':'/assets/logos/arc.svg','vbYkTRxoFHB1KElmmjmXx9TSsU.webp':'/assets/logos/linear.svg','NM6rQRZGZg9gw7HcNBtder6J2M.webp':'/assets/logos/screen-studio.svg'};
const img = (file, cls='', alt='', lazy=true) => {
  const fallback = file === 'WsnVxaSk0dKenAYdMT2G7bpCDAQ.png' ? (cls === 'portrait-img' ? '/assets/home-portrait-reference.webp' : cls === 'portrait-color-layer' ? '/assets/home-portrait-color.webp' : '/assets/portrait-fallback.webp') : (file === ABOUT_IMAGE ? '/assets/home-portrait-color.webp' : iconFiles[file]);
  const onerror = fallback ? `if(!this.dataset.localFallback){this.dataset.localFallback='1';this.src='${fallback}';}else{this.dataset.failed='true'}` : `this.dataset.failed='true'`;
  return `<img class="${cls}" src="${IMG}${file}" alt="${alt}" ${lazy?'loading="lazy"':'fetchpriority="high"'} decoding="async" onerror="${onerror}" />`;
};
const themeStorage = {get(){try{return localStorage.getItem('vexoo-theme')}catch{return null}},set(v){try{localStorage.setItem('vexoo-theme',v)}catch{}}};
let theme = themeStorage.get() || 'dark';
let cleanupScroll = () => {};
document.documentElement.dataset.theme = theme;
function clockText(){
  const options={hour:'numeric',minute:'2-digit'};
  if(siteConfig.timeZone && siteConfig.timeZone!=='auto') options.timeZone=siteConfig.timeZone;
  try{return new Intl.DateTimeFormat('en-US',options).format(new Date())}
  catch{return new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit'}).format(new Date())}
}
function cityText(){return siteConfig.locationLabel || 'Local time'}
function header({back=false,home=false}={}){
  const label = home?'Soren Weil':(back?'Back':'Home');const href=home?'/':(back?'/portfolio':'/');
  return `<header class="site-header reveal" aria-label="Site header">
    <a class="identity-link" href="${href}" data-link>${back?iconBack+'<span>Back</span>':home?'<span>'+profile.name+'</span>':iconBack+'<span>Home</span>'}</a>
    <span class="header-role">${profile.role}</span>
    <div class="header-right"><span class="location">${cityText()} <span class="sep">•</span> <time id="live-clock">${clockText()}</time></span>
    <button class="theme-toggle" aria-label="Toggle color theme" aria-pressed="${theme==='light'}" title="Switch between light and dark themes"><span class="toggle-dot"></span></button></div>
  </header>`;
}
function footer(){return `<footer class="site-footer reveal">
  <div class="footer-grid">
    <div><span class="footer-label">Email</span>${isDemo?`<span class="demo-contact" title="Sample email address">${profile.email}</span>`:`<a href="mailto:${profile.email}">${profile.email}</a>`}</div>
    <div><span class="footer-label">Phone</span>${isDemo?`<span class="demo-contact" title="Sample contact detail">${profile.phone}</span>`:`<a href="tel:${String(siteConfig.phoneDial||'').replace(/[^+\d]/g,'')}">${profile.phone}</a>`}</div>
    ${profile.social.map(s=>`<div><span class="footer-label">${s[0]}</span>${s[2]?`<a href="${s[2]}" target="_blank" rel="noreferrer noopener">${s[1]} ${iconArrow}</a>`:`<span class="social-unconfigured" title="Profile URL not configured">${s[1]}</span>`}</div>`).join('')}
  </div><div class="footer-bottom"><span>© ${new Date().getFullYear()} ${profile.name}</span><a href="#top" data-scroll-top>Back to top ↑</a></div>
</footer>`;}
function wrapper(content,opts={}){
 return `<div class="app-shell ${opts.home?'is-home':''}" id="top"><a class="skip-link" href="#main">Skip to content</a><div class="content-wrap">${header(opts)}<main id="main" tabindex="-1">${content}</main>${opts.home?'':footer()}</div><a class="template-pill" href="https://framer.link/8yundsi" target="_blank" rel="noopener noreferrer">Get this template ${iconArrow}</a>${opts.home?`<a class="framer-pill" href="https://www.framer.com/" target="_blank" rel="noopener noreferrer">◆ &nbsp; Made in Framer</a>`:''}</div>`;
}
function home(){
 return wrapper(`<div class="home-hero reveal"><h1 aria-label="Soren Weil">Soren <span>Weil</span></h1><span class="hero-wave">Hey <span aria-hidden="true">↗</span></span></div>
  <div class="bento" aria-label="Explore the portfolio">
    <a href="/about" data-link class="bento-card card-large tile-link reveal"><span class="tile-label">About</span>${iconArrow}<span class="hover-echo" aria-hidden="true">About</span></a>
    <a href="/portfolio" data-link class="bento-card card-large tile-link reveal"><span class="tile-label">Portfolio</span>${iconArrow}<span class="hover-echo" aria-hidden="true">Portfolio</span></a>
    <a href="/contact" data-link class="bento-card card-small tile-link reveal"><span class="tile-label">Contact</span>${iconArrow}<span class="hover-echo" aria-hidden="true">Contact</span></a>
    <a href="/about" data-link class="bento-card card-small portrait-card reveal" aria-label="About Soren Weil"><span class="portrait-pointer-light"></span>${img('WsnVxaSk0dKenAYdMT2G7bpCDAQ.png','portrait-img','Profile portrait of Soren Weil',false)}${img('WsnVxaSk0dKenAYdMT2G7bpCDAQ.png','portrait-color-layer','',false)}<span class="portrait-photo-fallback" aria-hidden="true"><span class="fallback-moon"></span><span class="fallback-silhouette"></span></span></a>
    <div class="bento-card card-small stack-card reveal"><span class="tile-label">Stack</span><div class="logo-marquee" aria-label="Favorite tools"><div class="logo-track">${[...tools,...tools,...tools].map((t,i)=>`<span class="logo-chip logo-${t[0].toLowerCase().replaceAll(' ','-')}" title="${t[0]}">${img(t[1],'tool-logo',t[0]+' logo')}<span class="logo-fallback" aria-hidden="true">${t[0].slice(0,1)}</span></span>`).join('')}</div></div></div>
    <a class="bento-card card-small tile-link reveal" href="${profile.resume}" target="_blank" rel="noopener noreferrer"><span class="tile-label">Resume</span>${iconArrow}<span class="hover-echo" aria-hidden="true">Resume</span></a>
  </div>`,{home:true});
}
function about(){
 return wrapper(`<section class="about-intro reveal"><h1 class="page-name">About</h1>
   <p class="big-biography" id="fade-text">I'm <strong>Soren Weil</strong> – a designer who believes the best work lives at the intersection of clarity and craft. I specialize in product experiences that feel considered from every angle, the layout, the type, the small details most people scroll past without noticing. Consistency matters to me, not as a rule, but because it's what makes a product feel trustworthy. Alongside my design practice, I'm building things of my own – driven by curiosity, a love for creative problem-solving, and a quiet need to make something that didn't exist before.</p></section>
   <figure class="about-portrait image-frame reveal">${img(ABOUT_IMAGE,'about-portrait-img','Portrait of Soren Weil facing left')}<figcaption>Soren Weil / AI Design Engineer</figcaption></figure>
   <section class="section-shell testimonials-section"><div class="section-header reveal"><h2>Kind words<span class="muted"> / 05</span></h2><div class="quote-controls"><button type="button" data-quote="prev" aria-controls="testimonials" aria-label="Previous testimonial">←</button><button type="button" data-quote="next" aria-controls="testimonials" aria-label="Next testimonial">→</button></div></div><div class="testimonials-rail" id="testimonials">${testimonials.map((t,i)=>`<article class="testimonial reveal"><span class="quote-mark">❝</span><p>${t[2]}</p><div class="quote-author"><strong>${t[0]}</strong><span>${t[1]}</span></div><small>0${i+1} / 05</small></article>`).join('')}</div></section>
   <section class="section-shell experience-section"><div class="section-header reveal"><h2>Experience<span class="muted"> / 04</span></h2></div><div class="timeline">${experiences.map(e=>`<article class="experience-row reveal"><div class="date">${e[0]}</div><div class="exp-job"><h3>${e[1]}</h3><p>${e[2]}</p></div><div class="exp-description">${e[3]}</div></article>`).join('')}</div></section>
   <section class="section-shell service-section reveal"><div class="section-header"><h2>What I do</h2></div>${['Digital Design','Art Direction','Framer Development'].map((s,i)=>`<div class="service-line"><span>0${i+1}</span><h3>${s}</h3><span class="service-dash">↗</span></div>`).join('')}</section>`);
}
function projectArtwork(p,variant=0){
  const categoryLabel={ 'travel-easy':'CULTURE TRIP', 'gamma':'GAMMA', 'stream-ai':'STREAM STUDIO', 'foome':'FOOME', 'edbost':'EDBOST' }[p.slug];
  const eyebrow={ 'travel-easy':'UNIQUE TRIPS · WITH CARE FOR THE WORLD', 'gamma':'IDEAS COME TO LIFE', 'stream-ai':'YOUR CREATIVE WORKSPACE', 'foome':'COOK SOMETHING GOOD', 'edbost':'A NEW WAY TO CREATE' }[p.slug];
  return `<div class="project-art art-${p.slug} art-variant-${variant%4}" aria-hidden="true"><div class="art-orb art-orb-left"></div><div class="art-orb art-orb-right"></div><div class="art-window"><div class="art-window-head"><span class="art-dots">● ● ●</span><span class="art-window-label">${categoryLabel}</span><span class="art-menu">···</span></div><div class="art-window-body"><div class="art-ui-side"><span class="art-side-dot"></span><span class="art-side-line"></span><span class="art-side-line short"></span><span class="art-side-line"></span></div><div class="art-ui-main"><span class="art-ui-eyebrow">${eyebrow}</span><strong>${p.title}</strong><span class="art-ui-sub">${p.category}</span><div class="art-mock-content"><span></span><span></span><span></span></div><span class="art-ui-pill">Explore ${p.title} <b>↗</b></span></div></div></div><span class="art-grain"></span></div>`;
}
function portfolio(){return wrapper(`<section class="portfolio-intro reveal"><h1>Dive into a few projects that represent my most fulfilling <span class="dim">design experiences</span></h1></section>
  <section class="portfolio-grid" aria-label="Selected projects">${projects.map((p,i)=>`<a href="/portfolio/${p.slug}" data-link class="project-tile reveal ${i===2?'wide':''}" aria-label="View ${p.title} project"><div class="project-cover" style="--cover:${i}">${img(p.images[0],'project-cover-img',p.title+' project cover')}${projectArtwork(p,0)}<span class="project-view">View project ${iconArrow}</span></div><div class="project-tile-info"><h2>${p.title}</h2><span>${p.category} ${iconArrow}</span></div></a>`).join('')}</section>`)}
function detail(p){let idx=projects.indexOf(p), prev=projects[idx-1],next=projects[idx+1];
 return wrapper(`<article class="case-study"><div class="case-heading reveal"><div><p class="eyebrow">SELECTED WORK / ${p.year}</p><h1>${p.title}</h1></div><span class="category-pill">${p.category}</span></div>
 <div class="case-hero image-frame reveal">${img(p.images[0],'case-image',p.title+' main project image',false)}${projectArtwork(p,0)}</div>
 <section class="case-summary reveal"><p>${p.description}</p><div class="case-meta">${[['Client',p.client],['Role',p.role],['Year',p.year]].map(v=>`<div><span>${v[0]}:</span><strong>${v[1]}</strong></div>`).join('')}</div></section>
 <div class="gallery-row reveal">${p.images.slice(1,3).map((f,i)=>`<div class="image-frame">${img(f,'case-image',p.title+' design mockup '+(i+2))}${projectArtwork(p,i+1)}</div>`).join('')}</div>
 <div class="story-trigger reveal"><span>Explore the full story –</span><a href="#case-story" class="round-down" aria-label="Scroll to case study story">↓</a></div>
 <section class="case-story" id="case-story">${[['Challenge',p.challenge],['Objective',p.objective],['Results',p.results]].map((s,i)=>`<article class="story-row reveal"><span class="story-num">0${i+1}</span><h2>${s[0]}</h2><p>${s[1]}</p></article>`).join('')}</section>
 <section class="case-gallery">${p.images.slice(3).map((f,i)=>`<div class="image-frame reveal gallery-${i+1}">${img(f,'case-image',p.title+' additional screen '+(i+4))}${projectArtwork(p,i+3)}</div>`).join('')}</section>
 <nav class="case-nav" aria-label="Adjacent projects">${prev?`<a href="/portfolio/${prev.slug}" data-link class="case-nav-item reveal"><small>← Prev</small><strong>${prev.title}</strong></a>`:'<div></div>'}${next?`<a href="/portfolio/${next.slug}" data-link class="case-nav-item next reveal"><small>Next →</small><strong>${next.title}</strong></a>`:'<div></div>'}</nav></article>`,{back:true});
}
function contact(){
 const projectTypes=['Multipage Website Design','Landing Page Design','Framer Website Development','Framer Landing Page Development'];
 const budgets=['$1k – $5k','$5k – $10k','$10k – $20k','> $20k'];
 return wrapper(`<section class="contact-intro reveal"><h1>If you prefer not to fill out forms, feel free to ${isDemo?`<span title="Sample contact email">email me directly</span>`:`<a href="mailto:${profile.email}">email me directly</a>`} and let's talk about the next big thing!</h1><div class="contact-intro-links">${isDemo?`<div class="demo-contact"><span>Phone</span><strong>${profile.phone}</strong><small>Sample number</small></div>`:`<a href="tel:${String(siteConfig.phoneDial||'').replace(/[^+\d]/g,'')}"><span>Phone</span><strong>${profile.phone}</strong></a>`}${isDemo?`<div class="demo-contact"><span>Email</span><strong>${profile.email}</strong><small>Sample email</small></div>`:`<a href="mailto:${profile.email}"><span>Email</span><strong>${profile.email}</strong></a>`}</div></section>
 <section class="form-container reveal">
 <form id="contact-form" novalidate autocomplete="on">
   <div class="two-fields"><label class="form-field"><span>Full name <b>*</b></span><input name="name" type="text" placeholder="ex. John Smith" required minlength="2" maxlength="120" autocomplete="name" aria-describedby="name-error" /><small class="field-error" id="name-error"></small></label><label class="form-field"><span>Email <b>*</b></span><input name="email" type="email" placeholder="hello@website.com" required maxlength="254" autocomplete="email" aria-describedby="email-error" /><small class="field-error" id="email-error"></small></label></div>
   <fieldset class="form-group"><legend>What's Your Project About?</legend><div class="choice-grid" role="group" aria-label="Project types">${projectTypes.map(v=>`<label class="choice"><input type="checkbox" name="projectType" value="${v}"/><span class="choice-check">✓</span><span>${v}</span></label>`).join('')}</div></fieldset>
   <fieldset class="form-group"><legend>Project Budget</legend><div class="choice-grid" role="radiogroup" aria-label="Project budget">${budgets.map(v=>`<label class="choice"><input type="radio" name="budget" value="${v.replaceAll('"','&quot;')}"/><span class="choice-check">✓</span><span>${v.replace('>','&gt;')}</span></label>`).join('')}</div></fieldset>
   <label class="form-field message-field"><span>Share More Details</span><textarea name="message" rows="5" maxlength="5000" placeholder="Tell me a little about your project, goals, and timelines..."></textarea></label>
   <div class="submit-row"><button type="submit" class="submit-button"><span>Submit</span>${iconArrow}</button><div class="availability"><span class="status-dot"></span> ${siteConfig.availabilityText || 'Project enquiries welcome'}</div></div><div id="form-status" role="status" aria-live="polite" aria-atomic="true"></div>
 </form></section>`);
}
function notFound(){return wrapper(`<section class="not-found reveal"><p class="eyebrow">ERROR / 404</p><h1>404<span>↗</span></h1><p>Looks like this page took a different direction.</p><a href="/" data-link class="back-home">${iconBack} Return home</a></section>`)}
function normalizePath(){let x=decodeURI(window.__previewPath || location.pathname).replace(/\/+$/,''); return x||'/'}
function render(){
 cleanupScroll();
 const path=normalizePath();const project = projects.find(p=>path==='/portfolio/'+p.slug);
 document.querySelector('#app').innerHTML=path==='/'?home():path==='/about'?about():path==='/portfolio'?portfolio():path==='/contact'?contact():project?detail(project):notFound();
 document.title = path==='/'?`${profile.name} — ${profile.role}`:(project?project.title:path.slice(1).replace(/^./,c=>c.toUpperCase()))+' — '+profile.name;
  const description = project ? `${project.title} — a ${project.category.toLowerCase()} case study.` : pageDescriptions[path] || 'Explore a considered design portfolio.';
  function setMeta(key,value,selector){let el=document.head.querySelector(selector);if(!el){el=document.createElement('meta');el.setAttribute(key.startsWith('og:')?'property':'name',key);document.head.appendChild(el)}el.setAttribute('content',value)}
  setMeta('description',description,'meta[name="description"]');setMeta('og:title',document.title,'meta[property="og:title"]');setMeta('og:description',description,'meta[property="og:description"]');
  setMeta('twitter:card','summary_large_image','meta[name="twitter:card"]');
  let canonical=document.head.querySelector('link[rel="canonical"]');if(!canonical){canonical=document.createElement('link');canonical.rel='canonical';document.head.appendChild(canonical)}
  if(location.protocol==='https:') canonical.href=location.origin+(path==='/'?'/':path);
  document.documentElement.setAttribute('data-route',path);
 document.querySelector('meta[name="theme-color"]').setAttribute('content',theme==='dark'?'#080808':'#f4f4f2');
 document.querySelectorAll('.reveal').forEach((el,i)=>{el.style.setProperty('--delay',`${Math.min(i%8*65,350)}ms`)});
 initReveal();initClock();initPointer();initCardHover();initQuote();initForm();initAboutText();
}
let revealObserver;
function initReveal(){revealObserver?.disconnect();const nodes=document.querySelectorAll('.reveal');if(!('IntersectionObserver' in window)){nodes.forEach(n=>n.classList.add('is-visible'));return}
 revealObserver=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');revealObserver.unobserve(e.target)}})},{rootMargin:'0px 0px -35px 0px',threshold:.07});nodes.forEach(n=>revealObserver.observe(n));}
function initClock(){const clock=document.getElementById('live-clock');if(clock)clock.textContent=clockText()}
setInterval(()=>{const c=document.getElementById('live-clock');if(c)c.textContent=clockText()},30000);
function initPointer(){
 if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;
 document.querySelectorAll('.portrait-card').forEach(el=>{
   let frame=0, bounds, pos={x:50,y:50,rx:0,ry:0};
   const commit=()=>{frame=0;el.style.setProperty('--px',pos.x.toFixed(2)+'%');el.style.setProperty('--py',pos.y.toFixed(2)+'%');el.style.setProperty('--rx',pos.rx.toFixed(2)+'deg');el.style.setProperty('--ry',pos.ry.toFixed(2)+'deg')};
   el.addEventListener('pointerenter',()=>{bounds=el.getBoundingClientRect();el.style.setProperty('--photo-reveal','1')});
   el.addEventListener('pointermove',e=>{
     if(!matchMedia('(pointer:fine)').matches)return;
     bounds ||= el.getBoundingClientRect();
     const x=Math.max(0,Math.min(1,(e.clientX-bounds.left)/bounds.width));
     const y=Math.max(0,Math.min(1,(e.clientY-bounds.top)/bounds.height));
     pos={x:x*100,y:y*100,rx:(.5-y)*12,ry:(x-.5)*16};
     if(!frame)frame=requestAnimationFrame(commit);
   },{passive:true});
   el.addEventListener('focusin',()=>el.style.setProperty('--photo-reveal','1'));
   el.addEventListener('focusout',()=>el.style.setProperty('--photo-reveal','0'));
   el.addEventListener('pointerleave',()=>{if(frame)cancelAnimationFrame(frame);frame=0;bounds=null;pos={x:50,y:50,rx:0,ry:0};commit();el.style.setProperty('--photo-reveal','0')});
 });
}
function initCardHover(){
 if(!window.matchMedia('(hover:hover) and (pointer:fine)').matches || window.matchMedia('(prefers-reduced-motion:reduce)').matches)return;
 document.querySelectorAll('.is-home .tile-link').forEach(card=>{
   let frame=0, point={x:50,y:50};
   card.addEventListener('pointermove',e=>{
     const rect=card.getBoundingClientRect();point.x=100*(e.clientX-rect.left)/rect.width;point.y=100*(e.clientY-rect.top)/rect.height;
     if(frame)return;frame=requestAnimationFrame(()=>{frame=0;card.style.setProperty('--hover-x',point.x.toFixed(2)+'%');card.style.setProperty('--hover-y',point.y.toFixed(2)+'%');});
   },{passive:true});
   card.addEventListener('pointerleave',()=>{card.style.removeProperty('--hover-x');card.style.removeProperty('--hover-y');if(frame){cancelAnimationFrame(frame);frame=0}});
 });
}
function initQuote(){
 const el=document.getElementById('testimonials');if(!el)return;
 const controls=[...document.querySelectorAll('[data-quote]')];
 const sync=()=>{const end=el.scrollWidth-el.clientWidth;controls.forEach(btn=>{btn.disabled=btn.dataset.quote==='prev'?el.scrollLeft<2:el.scrollLeft>=end-2})};
 controls.forEach(btn=>btn.addEventListener('click',()=>{const card=el.querySelector('.testimonial');if(!card)return;el.scrollBy({left:(btn.dataset.quote==='next'?1:-1)*(card.getBoundingClientRect().width+16),behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});setTimeout(sync,400)}));
 el.addEventListener('scroll',sync,{passive:true});sync();
}
function initAboutText(){
 const el=document.getElementById('fade-text');if(!el)return;
 if(window.matchMedia('(prefers-reduced-motion:reduce)').matches) return;
 const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);
 const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
 nodes.forEach(node=>{const frag=document.createDocumentFragment();const chunks=node.textContent.match(/\S+|\s+/g)||[];
   chunks.forEach(chunk=>{if(/^\s+$/.test(chunk)){frag.append(document.createTextNode(chunk))}else{const span=document.createElement('span');span.className='bio-word';span.textContent=chunk;frag.append(span)}});
   node.replaceWith(frag);
 });
 el.classList.add('bio-enhanced');const words=[...el.querySelectorAll('.bio-word')];let scheduled=false;
 const update=()=>{scheduled=false;if(!el.isConnected)return;const r=el.getBoundingClientRect();const progress=Math.max(.05,Math.min(1,(innerHeight*.58-r.top)/Math.max(200,r.height*.55)));
   const count=Math.floor(words.length*progress);words.forEach((word,i)=>word.classList.toggle('is-lit',i<count));};
 const onScroll=()=>{if(!scheduled){scheduled=true;requestAnimationFrame(update)}};
 window.addEventListener('scroll',onScroll,{passive:true});window.addEventListener('resize',onScroll,{passive:true});
 cleanupScroll=()=>{window.removeEventListener('scroll',onScroll);window.removeEventListener('resize',onScroll)};
 update();
}
function initForm(){const form=document.getElementById('contact-form');if(!form)return;
 form.addEventListener('submit', async e=>{e.preventDefault();const name=form.elements.name,email=form.elements.email,status=document.getElementById('form-status');
  form.querySelectorAll('.field-error').forEach(x=>x.textContent='');name.removeAttribute('aria-invalid');email.removeAttribute('aria-invalid');status.textContent='';status.className='';let valid=true;
  if(name.value.trim().length<2){form.querySelector('#name-error').textContent='Please enter your full name.';name.setAttribute('aria-invalid','true');valid=false}
  if(!email.validity.valid){form.querySelector('#email-error').textContent='Please enter a valid email address.';email.setAttribute('aria-invalid','true');valid=false}
  if(!valid){status.textContent='Please check the highlighted fields.';status.className='error';return}
  const selected=[...form.querySelectorAll('[name="projectType"]:checked')].map(x=>x.value);
  const values={name:name.value.trim(),email:email.value.trim(),projectTypes:selected,budget:form.querySelector('[name="budget"]:checked')?.value||'Not specified',details:form.elements.message.value.trim()};
  const endpoint=siteConfig.formEndpoint || window.VEXOO_CONFIG?.formEndpoint;
  if(endpoint){const button=form.querySelector('button[type="submit"]');button.disabled=true;button.querySelector('span').textContent='Sending...';try{const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);try{const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values),signal:controller.signal});if(!r.ok)throw Error('Unable to send');status.className='success';status.textContent='Thank you — the submission endpoint accepted your enquiry.';form.reset()}finally{clearTimeout(timer)}}catch(err){status.className='error';status.textContent='Submission failed. Please email '+profile.email+' directly.'}finally{button.disabled=false;button.querySelector('span').textContent='Submit'}return}
  status.className='notice';status.textContent='Preview only: no message was sent. A verified contact endpoint must be configured before this form can receive enquiries.';
 });}
function go(path){if(normalizePath()!==path){try{history.pushState({},'',path);window.__previewPath=''}catch(_e){window.__previewPath=path}}window.scrollTo({top:0,behavior:'instant'});document.documentElement.classList.add('route-switching');render();requestAnimationFrame(()=>document.documentElement.classList.remove('route-switching'));document.getElementById('main')?.focus({preventScroll:true})}
document.addEventListener('click',e=>{const topLink=e.target.closest('[data-scroll-top]');if(!topLink)return;e.preventDefault();window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});document.getElementById('main')?.focus({preventScroll:true})});
document.addEventListener('click',e=>{let link=e.target.closest('a[data-link]');if(link&&!e.metaKey&&!e.ctrlKey&&!e.shiftKey&&!e.altKey&&e.button===0){e.preventDefault();const target=link.getAttribute('href');go(target?.startsWith('/')?target:new URL(link.href,location.href).pathname)}});
document.addEventListener('click',e=>{let btn=e.target.closest('.theme-toggle');if(!btn)return;theme=theme==='dark'?'light':'dark';themeStorage.set(theme);document.documentElement.dataset.theme=theme;btn.setAttribute('aria-pressed',theme==='light');btn.setAttribute('aria-label',theme==='dark'?'Switch to light theme':'Switch to dark theme');document.querySelector('meta[name="theme-color"]').content=theme==='dark'?'#080808':'#f4f4f2'});
window.addEventListener('popstate',()=>{window.scrollTo({top:0,behavior:'instant'});render()});
render();
