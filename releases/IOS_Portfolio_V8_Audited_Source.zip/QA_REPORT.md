# Vexoo V2 — Reference Fidelity and Local QA

Reference: https://vexoo.framer.website/
Audit date: November 14, 2026

## Changes since the first recreation

- Home: larger aligned name, tighter card rhythm, corrected Cairo clock, photo hover, original tool icons primary with local SVG alternatives.
- About: reference-based biography content; scroll-reveal wording; generated fallback portrait if offline; stronger mobile typographic rhythm.
- Portfolio: source-oriented title and project card structure; project artwork alternatives render if remote original imagery fails.
- Five detail pages: hero, project meta, gallery, challenges, objectives, results, previous/next navigation and image fallback art.
- Contact: removed invented heading/progress label; verified inputs, selection controls and submission validation; availability text matches the reference (May 2026, now historic).
- Accessibility: reduced-motion handling, accessible focus, mobile overflow checks, meaningful fallback imagery.

## Automated local checks

- 9 route states × 3 viewports (1440×960, 768×1024, 390×844) = 27 successful render tests.
- No uncaught page errors, all route states contain an h1, no horizontal overflow.
- Tested theme toggle, form input validation, selection controls.
- Confirmed JavaScript parses with `node --check`.

## Not fully verified

- Pixel-perfect geometry against original Framer screenshots at identical viewports.
- Exact fonts and computed values from original site.
- Exact cursor, scroll, stagger and 3D animation timing.
- Every original artwork's download/license status.
- Real contact-form delivery (needs endpoint).
- External social links and final production content ownership.

This is a closer **independent recreation**, not the editable Framer project. For precise source implementation, obtain the original via the official template's Remix option under the applicable license.
