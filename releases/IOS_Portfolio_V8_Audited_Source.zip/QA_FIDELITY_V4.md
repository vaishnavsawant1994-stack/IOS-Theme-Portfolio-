# Vexoo V4 Fidelity Report — 2026-11-14

## Verified differences from V3
- V3 stretched Home to 1190–1320px; V4 limits it to 800px, centered on large screens.
- V3 allowed inner pages up to 1500px; V4 limits inner pages to 930px.
- Refined hero, tile sizes, portrait crop, labels, gutters, and responsive breakpoints.
- Changed portrait image source to the publicly referenced Framer image name.
- Updated time and city display for the Pune target environment.

## Test method
- Rendered with local Chromium using the self-contained HTML file and route states.
- Tested 9 route states across 320, 360, 390, 430, 768, 1024, 1280, 1440, 1920, and 2560px (90 checks).
- Zero JavaScript errors; no horizontal overflow or heading clipping.
- Inspected full-height screenshots at 390, 768, 1440 and 1920px.
- The source browser is read-only, so exact live original computed styles, video hover timings, and direct side-by-side pixel diff were not available.
- Original Framer photography and CMS media rely on external URLs. Contact form is an email draft, not an operational submissions backend.

## Known remaining non-identical details
- Project graphics are approximations if originals cannot load.
- Testimonial and case-study copy is adapted.
- Framer-specific motion implementation, layout constraints, and font metrics not independently measured.
