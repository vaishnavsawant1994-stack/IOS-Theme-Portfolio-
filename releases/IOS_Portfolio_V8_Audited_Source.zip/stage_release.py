from pathlib import Path
import shutil,json,hashlib,re
root=Path('/mnt/data/ios-portfolio-v8')
release=root/'git-release'
if release.exists():shutil.rmtree(release)
shutil.copytree(root/'dist',release,ignore=shutil.ignore_patterns('manifest.json'))
for a,b in [('README.md','README.md'),('package.json','package.json'),('docs/RELEASE_AUDIT_V8.md','docs/RELEASE_AUDIT_V8.md'),('tests/source.test.mjs','tests/source.test.mjs'),('.github/workflows/ci.yml','.github/workflows/ci.yml')]:
 dest=release/b;dest.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(root/a,dest)
# Adjust repo-specific npm tests to use static entrypoints directly instead of /dist
p=release/'tests/source.test.mjs';s=p.read_text().replace("const css=read('quality-v8.css');", "const css=read('styles.css');").replace("path.join(root,'dist',name)","path.join(root,name)");p.write_text(s)
# Reproducible 1:1 rebuild of standalone preview, including the same scripts and inline CSS.
tools=release/'tools';tools.mkdir(exist_ok=True)
(tools/'build.mjs').write_text('''import fs from 'node:fs';import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
const config=fs.readFileSync(path.join(root,'site-config.js'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
html=html.replace('<link rel="stylesheet" href="/styles.css" />','<style>'+css+'</style>');
html=html.replace('<script defer src="/site-config.js"></script>','');
html=html.replace('<script defer src="/app.js"></script>','');
html=html.replace('</body>','<script>'+config+'</script>\\n<script>'+app+'</script>\\n</body>');
fs.writeFileSync(path.join(root,'preview.html'),html);
console.log('Rebuilt preview.html');
''')
p=release/'package.json';obj=json.loads(p.read_text());obj['scripts']['build']='node tools/build.mjs';p.write_text(json.dumps(obj,indent=2)+'\n')
# README difference local source vs root deployment
p=release/'README.md';s=p.read_text().replace('`npm run build` — build `/dist` for static hosting. This script embeds locally bundled fallback images so remote hosting requires only HTML/CSS/JS.', '`npm run build` — regenerate `preview.html` from `app.js`, `site-config.js`, `styles.css` and `index.html` (already bundled for static hosting).')
s=s.replace('`dist/preview.html`','`preview.html`').replace('`dist/index.html`','`index.html`').replace('Upload **the contents of `dist`**, not the outer directory. Deploying from source requires rebuilding after edits.', 'Deploy this repository root (HTML/CSS/JS/static route directories). The standalone preview must be rebuilt after editing runtime files.')
p.write_text(s)
# Exclude changed snapshot outputs and stale reference files from transfer.
paths=[]
for f in sorted(release.rglob('*')):
 if f.is_file():paths.append((f.relative_to(release).as_posix(),f.read_text()))
# text transfer files are HTML wrappers containing a single JSON line (no markup/parser ambiguity).
groups=[];group=[];size=0
for name,content in paths:
 obj={'path':name,'content':content};n=len(json.dumps(obj,ensure_ascii=True))
 if group and size+n>180000:
  groups.append(group);group=[];size=0
 group.append(obj);size+=n
if group:groups.append(group)
for i,entries in enumerate(groups,1):
 fp=Path('/mnt/data')/f'IOS_Portfolio_V8_TRANSFER_{i:02d}.html'
 fp.write_text('<!doctype html>\n<pre id="json">\n'+json.dumps(entries,ensure_ascii=True,separators=(',',':'))+'\n</pre>')
 print(fp,fp.stat().st_size,len(entries))
print('RELEASE_FILES',len(paths),'TOTAL_BYTES',sum(len(x[1]) for x in paths))
