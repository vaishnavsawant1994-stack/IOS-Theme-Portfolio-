from pathlib import Path
import re, json, base64
root=Path('/mnt/data/ios-portfolio-v8')
p=root/'app.js'; s=p.read_text()
def rep(a,b,count=1):
 global s
 n=s.count(a)
 if n!=count: raise Exception(f'Expected {count} replacements; found {n}: {a[:100]}')
 s=s.replace(a,b)

rep("const IMG = 'https://framerusercontent.com/images/';", """const IMG = 'https://framerusercontent.com/images/';
// Editable values live in site-config.js. The public preview intentionally uses demo data.
const siteConfig = window.IOS_PORTFOLIO_CONFIG || {};
const isDemo = siteConfig.mode !== 'production';
const pageDescriptions = {
 '/': 'A considered portfolio of digital design, visual craft and creative projects.',
 '/about': 'Learn about the approach, experience and creative practice behind the portfolio.',
 '/portfolio': 'Selected digital products, visual design, websites and case studies.',
 '/contact': 'Get in touch about product design, visual identity and website projects.'
};
""")
rep("name: 'Soren Weil', role: 'AI Design Engineer', email: 'hello@soren.com', phone: '(+20) 115 123-4567',", "name: siteConfig.name || 'Soren Weil', role: siteConfig.role || 'AI Design Engineer', email: siteConfig.email || 'hello@soren.com', phone: siteConfig.phone || '(+20) 115 123-4567',")
rep("resume: 'https://drive.google.com/file/d/167um-hT0g-Xc2ClPDNb0z40feV9LT7e2/view?usp=drive_link',", "resume: siteConfig.resume || 'https://drive.google.com/file/d/167um-hT0g-Xc2ClPDNb0z40feV9LT7e2/view?usp=drive_link',")
rep("['X (Twitter)', '@soren.weil', 'https://x.com/'],\n    ['Instagram', '@its-soren', 'https://www.instagram.com/'],\n    ['LinkedIn', '@weil.soren', 'https://www.linkedin.com/']", "['X (Twitter)', siteConfig.socialHandles?.x || '@soren.weil', siteConfig.socialProfiles?.x || ''],\n    ['Instagram', siteConfig.socialHandles?.instagram || '@its-soren', siteConfig.socialProfiles?.instagram || ''],\n    ['LinkedIn', siteConfig.socialHandles?.linkedin || '@weil.soren', siteConfig.socialProfiles?.linkedin || '']")
rep("function clockText(){return new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit',timeZone:'Asia/Kolkata'}).format(new Date())}\nfunction cityText(){return 'Pune'}", """function clockText(){
  const options={hour:'numeric',minute:'2-digit'};
  if(siteConfig.timeZone && siteConfig.timeZone!=='auto') options.timeZone=siteConfig.timeZone;
  try{return new Intl.DateTimeFormat('en-US',options).format(new Date())}
  catch{return new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit'}).format(new Date())}
}
function cityText(){return siteConfig.locationLabel || 'Local time'}""")
rep("<span class=\"header-role\">AI Design Engineer</span>","<span class=\"header-role\">${profile.role}</span>")
rep("<span>Soren Weil</span>'", "<span>${profile.name}</span>'")
rep("<div><span class=\"footer-label\">Phone</span><a href=\"tel:+201151234567\">${profile.phone}</a></div>", "<div><span class=\"footer-label\">Phone</span>${isDemo?`<span class=\"demo-contact\" title=\"Sample contact detail\">${profile.phone}</span>`:`<a href=\"tel:${String(siteConfig.phoneDial||'').replace(/[^+\\d]/g,'')}\">${profile.phone}</a>`}</div>")
rep("${profile.social.map(s=>`<div><span class=\"footer-label\">${s[0]}</span><a href=\"${s[2]}\" target=\"_blank\" rel=\"noreferrer noopener\">${s[1]} ${iconArrow}</a></div>`).join('')}", "${profile.social.map(s=>`<div><span class=\"footer-label\">${s[0]}</span>${s[2]?`<a href=\"${s[2]}\" target=\"_blank\" rel=\"noreferrer noopener\">${s[1]} ${iconArrow}</a>`:`<span class=\"social-unconfigured\" title=\"Profile URL not configured\">${s[1]}</span>`}</div>`).join('')}")
rep("<span>© ${new Date().getFullYear()} Soren Weil</span><a href=\"/\" data-link>Back to top ↑</a>","<span>© ${new Date().getFullYear()} ${profile.name}</span><a href=\"#top\" data-scroll-top>Back to top ↑</a>")
rep("<div class=\"app-shell ${opts.home?'is-home':''}\"><div class=\"content-wrap\">", "<div class=\"app-shell ${opts.home?'is-home':''}\" id=\"top\"><a class=\"skip-link\" href=\"#main\">Skip to content</a><div class=\"content-wrap\">")
rep("<div class=\"quote-controls\"><button type=\"button\" data-quote=\"prev\" aria-label=\"Previous testimonial\">←</button><button type=\"button\" data-quote=\"next\" aria-label=\"Next testimonial\">→</button></div>","<div class=\"quote-controls\"><button type=\"button\" data-quote=\"prev\" aria-controls=\"testimonials\" aria-label=\"Previous testimonial\">←</button><button type=\"button\" data-quote=\"next\" aria-controls=\"testimonials\" aria-label=\"Next testimonial\">→</button></div>")
rep('<a href="tel:+201151234567"><span>Phone</span><strong>${profile.phone}</strong></a>', "${isDemo?`<div class=\"demo-contact\"><span>Phone</span><strong>${profile.phone}</strong><small>Sample number</small></div>`:`<a href=\"tel:${String(siteConfig.phoneDial||'').replace(/[^+\\d]/g,'')}\"><span>Phone</span><strong>${profile.phone}</strong></a>`}")
rep('name="name" type="text" placeholder="ex. John Smith" required minlength="2"', 'name="name" type="text" placeholder="ex. John Smith" required minlength="2" maxlength="120"')
rep('name="email" type="email" placeholder="hello@website.com" required', 'name="email" type="email" placeholder="hello@website.com" required maxlength="254"')
rep('name="message" rows="5" placeholder="Tell me a little about your project, goals, and timelines..."','name="message" rows="5" maxlength="5000" placeholder="Tell me a little about your project, goals, and timelines..."')
rep('<span class="status-dot"></span> One spot available for May, 2026','<span class="status-dot"></span> ${siteConfig.availabilityText || \'Project enquiries welcome\'}')
rep('id="form-status" role="status" aria-live="polite"', 'id="form-status" role="status" aria-live="polite" aria-atomic="true"')
rep('const endpoint=window.VEXOO_CONFIG?.formEndpoint;', 'const endpoint=siteConfig.formEndpoint || window.VEXOO_CONFIG?.formEndpoint;')
rep("const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values)});if(!r.ok)throw Error('Unable to send');status.className='success';status.textContent='Thank you — your enquiry has been submitted.';form.reset()", "const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);try{const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values),signal:controller.signal});if(!r.ok)throw Error('Unable to send');status.className='success';status.textContent='Thank you — the submission endpoint accepted your enquiry.';form.reset()}finally{clearTimeout(timer)}")
# Explicit preview state: do not send a visitor's details to an unverified sample address.
a="""  const subject=encodeURIComponent('Project enquiry from '+values.name);
  const body=encodeURIComponent(['Name: '+values.name,'Email: '+values.email,'Project: '+(values.projectTypes.join(', ')||'Not specified'),'Budget: '+values.budget,'','Details:',values.details||'Not provided'].join('\\n'));
  status.className='notice';status.textContent='Email draft prepared. Please send it from your email application to complete your enquiry.';
  const link=document.createElement('a');link.href=`mailto:${profile.email}?subject=${subject}&body=${body}`;document.body.append(link);link.click();link.remove();"""
b="""  status.className='notice';status.textContent='Preview only: no message was sent. A verified contact endpoint must be configured before this form can receive enquiries.';"""
rep(a,b)
# Render metadata from route only, never text from untrusted user input.
rep("document.title = path==='/'?'Soren Weil — AI Design Engineer':(project?project.title:path.slice(1).replace(/^./,s=>s.toUpperCase()))+' — Soren Weil';", """document.title = path==='/'?`${profile.name} — ${profile.role}`:(project?project.title:path.slice(1).replace(/^./,c=>c.toUpperCase()))+' — '+profile.name;
  const description = project ? `${project.title} — a ${project.category.toLowerCase()} case study.` : pageDescriptions[path] || 'Explore a considered design portfolio.';
  function setMeta(key,value,selector){let el=document.head.querySelector(selector);if(!el){el=document.createElement('meta');el.setAttribute(key.startsWith('og:')?'property':'name',key);document.head.appendChild(el)}el.setAttribute('content',value)}
  setMeta('description',description,'meta[name="description"]');setMeta('og:title',document.title,'meta[property="og:title"]');setMeta('og:description',description,'meta[property="og:description"]');
  setMeta('twitter:card','summary_large_image','meta[name="twitter:card"]');
  let canonical=document.head.querySelector('link[rel="canonical"]');if(!canonical){canonical=document.createElement('link');canonical.rel='canonical';document.head.appendChild(canonical)}
  if(location.protocol==='https:') canonical.href=location.origin+(path==='/'?'/':path);
  document.documentElement.setAttribute('data-route',path);""")
# quote scroll controls avoid broken state; update aria-disabled at edges
rep("function initQuote(){const el=document.getElementById('testimonials');if(!el)return;document.querySelectorAll('[data-quote]').forEach(btn=>btn.addEventListener('click',()=>el.scrollBy({left:(btn.dataset.quote==='next'?1:-1)*(el.querySelector('.testimonial').getBoundingClientRect().width+16),behavior:'smooth'})))}", """function initQuote(){
 const el=document.getElementById('testimonials');if(!el)return;
 const controls=[...document.querySelectorAll('[data-quote]')];
 const sync=()=>{const end=el.scrollWidth-el.clientWidth;controls.forEach(btn=>{btn.disabled=btn.dataset.quote==='prev'?el.scrollLeft<2:el.scrollLeft>=end-2})};
 controls.forEach(btn=>btn.addEventListener('click',()=>{const card=el.querySelector('.testimonial');if(!card)return;el.scrollBy({left:(btn.dataset.quote==='next'?1:-1)*(card.getBoundingClientRect().width+16),behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});setTimeout(sync,400)}));
 el.addEventListener('scroll',sync,{passive:true});sync();
}""")
# pointer effect: track non-transformed rectangle once and throttle in RAF.
start=s.index('function initPointer(){');end=s.index('function initCardHover(){',start)
s=s[:start]+"""function initPointer(){
 if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;
 document.querySelectorAll('.portrait-card').forEach(el=>{
   let frame=0, bounds, pos={x:50,y:50,rx:0,ry:0};
   const commit=()=>{frame=0;el.style.setProperty('--px',pos.x.toFixed(2)+'%');el.style.setProperty('--py',pos.y.toFixed(2)+'%');el.style.setProperty('--rx',pos.rx.toFixed(2)+'deg');el.style.setProperty('--ry',pos.ry.toFixed(2)+'deg')};
   el.addEventListener('pointerenter',()=>{bounds=el.getBoundingClientRect();el.style.setProperty('--photo-reveal','1')});
   el.addEventListener('pointermove',e=>{
     if(!matchMedia('(pointer:fine)').matches)return;
     bounds ||= el.getBoundingClientRect();
     const x=Math.max(0,Math.min(1,(e.clientX-bounds.left)/bounds.width));
     const y=Math.max(0,Math.min(1,(e.clientY-bounds.top)/bounds.height));
     pos={x:x*100,y:y*100,rx:(.5-y)*12,ry:(x-.5)*16};
     if(!frame)frame=requestAnimationFrame(commit);
   },{passive:true});
   el.addEventListener('focusin',()=>el.style.setProperty('--photo-reveal','1'));
   el.addEventListener('focusout',()=>el.style.setProperty('--photo-reveal','0'));
   el.addEventListener('pointerleave',()=>{if(frame)cancelAnimationFrame(frame);frame=0;bounds=null;pos={x:50,y:50,rx:0,ry:0};commit();el.style.setProperty('--photo-reveal','0')});
 });
}
"""+s[end:]
# scroll-to-top works within current route, preserve same page and update focus
rep("document.addEventListener('click',e=>{let link=e.target.closest('a[data-link]');", """document.addEventListener('click',e=>{const topLink=e.target.closest('[data-scroll-top]');if(!topLink)return;e.preventDefault();window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});document.getElementById('main')?.focus({preventScroll:true})});
document.addEventListener('click',e=>{let link=e.target.closest('a[data-link]');""")
# enforce visibly accurate language in theme toggle
rep("btn.setAttribute('aria-pressed',theme==='light');", "btn.setAttribute('aria-pressed',theme==='light');btn.setAttribute('aria-label',theme==='dark'?'Switch to light theme':'Switch to dark theme');")
# add valid href to top anchor even file view; no route conflict
p.write_text(s)

config="""// Set real values before publishing as a personal or business portfolio.
// With mode=demo, social profile links are inactive and form submissions are not sent.
window.IOS_PORTFOLIO_CONFIG = {
  mode: 'demo',
  name: 'Soren Weil',
  role: 'AI Design Engineer',
  email: 'hello@soren.com',       // example only
  phone: '(+20) 115 123-4567',   // example only
  phoneDial: '',                  // set verified E.164 number for production
  resume: 'https://drive.google.com/file/d/167um-hT0g-Xc2ClPDNb0z40feV9LT7e2/view?usp=drive_link',
  locationLabel: 'Local time',
  timeZone: 'auto',
  availabilityText: 'Project enquiries welcome',
  formEndpoint: '',               // verified HTTPS POST endpoint; required for delivery
  socialHandles: {x:'@soren.weil',instagram:'@its-soren',linkedin:'@weil.soren'},
  socialProfiles: {x:'',instagram:'',linkedin:''}
};
"""
(root/'site-config.js').write_text(config)
# Additional accessibility and mobile QA adjustments, retain screenshot-measured grid.
(root/'quality-v8.css').write_text("""
/* V8: focused quality fixes. Keep V7 reference-matched desktop grid unchanged. */
.skip-link{position:fixed;z-index:1000;top:-80px;left:16px;padding:12px 18px;border-radius:12px;background:var(--ink);color:var(--bg);font-size:14px;font-weight:700;box-shadow:0 8px 24px #0006}
.skip-link:focus-visible{top:12px;outline:2px solid var(--focus);outline-offset:4px}
.social-unconfigured,.demo-contact{color:var(--muted);cursor:default}
.contact-intro-links .demo-contact{display:flex;flex-direction:column;gap:8px}
.demo-contact small{font-size:11px;color:var(--muted)}
#form-status:not(:empty){padding:12px 0;font-size:13px;line-height:1.55;max-width:600px}
#form-status.notice{color:var(--ink)}
#form-status.error{color:#ef9a9a}
:root[data-theme='light'] #form-status.error{color:#a01a1a}
#form-status.success{color:#7adab0}
:root[data-theme='light'] #form-status.success{color:#166f49}
.quote-controls button:disabled{opacity:.35;cursor:not-allowed}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}}
@media(max-width:699px){.skip-link:focus-visible{left:12px;top:9px}.contact-intro-links .demo-contact{min-width:0}}
""")
# Site config and quality CSS loaded explicitly, after legacy styles to avoid regressions.
for entry in [root/'index.html',root/'404.html']:
 h=entry.read_text();h=h.replace('<link rel="stylesheet" href="/fidelity-v7.css" />','<link rel="stylesheet" href="/fidelity-v7.css" />\n  <link rel="stylesheet" href="/quality-v8.css" />');h=h.replace('<script defer src="/app.js"></script>','<script defer src="/site-config.js"></script>\n  <script defer src="/app.js"></script>');entry.write_text(h)
print('Patches complete. JS',len(s),'characters')
