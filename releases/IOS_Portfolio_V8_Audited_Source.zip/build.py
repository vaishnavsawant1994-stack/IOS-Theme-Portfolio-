from pathlib import Path
import base64,re,html,json,hashlib,zipfile
root=Path(__file__).resolve().parent
css_names=['styles.css','precision.css','responsive.css','fidelity-v4.css','fidelity-v5.css','fidelity-v6.css','fidelity-v7.css','quality-v8.css']
css='\n'.join((root/name).read_text() for name in css_names)
js=(root/'app.js').read_text()
config=(root/'site-config.js').read_text()
for asset in (root/'assets').rglob('*'):
 if not asset.is_file():continue
 mime={'svg':'image/svg+xml','webp':'image/webp','png':'image/png','jpg':'image/jpeg'}[asset.suffix[1:]]
 original='/'+asset.relative_to(root).as_posix()
 replacement='data:'+mime+';base64,'+base64.b64encode(asset.read_bytes()).decode()
 js=js.replace(original, replacement)
# Output assembled editable production build: only 4 assets needed for static deploy.
dist=root/'dist';dist.mkdir(exist_ok=True)
(dist/'styles.css').write_text(css)
(dist/'app.js').write_text(js)
(dist/'site-config.js').write_text(config)
paths=['/','/about','/portfolio','/contact','/portfolio/travel-easy','/portfolio/gamma','/portfolio/stream-ai','/portfolio/foome','/portfolio/edbost','/404']
meta={
 '/':('Soren Weil — AI Design Engineer','Independent design portfolio demo with selected digital product and website work.'),
 '/about':('About — Soren Weil','An introduction to design experience, working approach and creative services.'),
 '/portfolio':('Portfolio — Soren Weil','Five selected product, website and visual design project case studies.'),
 '/contact':('Contact — Soren Weil','Contact information and a project enquiry form demonstration.'),
}
for p in paths:
 if p.startswith('/portfolio/'):
  name=p.rsplit('/',1)[-1].replace('-',' ').title();meta[p]=(f'{name} — Soren Weil',f'A design case study exploring the {name} project and visual process.')
 if p=='/404':meta[p]=('Page not found — Soren Weil','The requested page was not found.')
def entry(p):
 title, desc=meta[p]
 return f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
  <meta name="theme-color" content="#080808" />
  <meta name="description" content="{html.escape(desc,quote=True)}" />
  <meta property="og:title" content="{html.escape(title,quote=True)}" />
  <meta property="og:description" content="{html.escape(desc,quote=True)}" />
  <meta property="og:type" content="website" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="robots" content="noindex,nofollow" />
  <link rel="preconnect" href="https://framerusercontent.com" crossorigin />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;450;500;550;600;650;700;750&display=swap" rel="stylesheet" />
  <title>{html.escape(title)}</title>
  <link rel="stylesheet" href="/styles.css" />
  <script defer src="/site-config.js"></script>
  <script defer src="/app.js"></script>
</head>
<body>
  <div id="app"></div>
  <noscript>Please enable JavaScript to explore this portfolio.</noscript>
</body>
</html>
'''
for p in paths:
 file=dist/('404.html' if p=='/404' else p.strip('/')+'/index.html' if p!='/' else 'index.html')
 file.parent.mkdir(exist_ok=True,parents=True)
 file.write_text(entry(p))
# Static preview should not be indexed before verified owner and destination domain are provided.
(dist/'robots.txt').write_text('User-agent: *\nDisallow: /\n')
# Browser-only preview with embedded media and source; no server needed.
preview=entry('/').replace('<link rel="stylesheet" href="/styles.css" />','<style>'+css+'</style>')
preview=preview.replace('<script defer src="/site-config.js"></script>','')
preview=preview.replace('<script defer src="/app.js"></script>','')
preview=preview.replace('</body>', '<script>'+config+'</script>\n<script>'+js+'</script>\n</body>')
(dist/'preview.html').write_text(preview)
# checksums from packaged files are identical to those offered to deployment/GitHub.
files=[p for p in dist.rglob('*') if p.is_file() and p.name not in ('preview.html','manifest.json')]
manifest={p.relative_to(dist).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(dist/'manifest.json').write_text(json.dumps({'version':'v8','source':'IOS-Theme-Portfolio-','files':manifest},indent=2))
zip_path=Path('/mnt/data/IOS_Portfolio_V8_Audited_Source.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  if p.is_file() and p!=zip_path and '/__pycache__/' not in str(p) and '/git-release/' not in str(p) and p.suffix!='.png' and p.name not in ('preaudit.py',):
   z.write(p,p.relative_to(root))
print(f'dist: {len(files)} files, js {len(js)} chars, css {len(css)} chars, zip {zip_path.stat().st_size} bytes')
